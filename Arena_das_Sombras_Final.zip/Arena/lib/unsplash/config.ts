export const UNSPLASH_ACCESS_KEY = process.env.UNSPLASH_ACCESS_KEY || 'h8FkAaPkV5wzScIXMWwbQ48-SLIdzpj82lRLj6aqTrU';

